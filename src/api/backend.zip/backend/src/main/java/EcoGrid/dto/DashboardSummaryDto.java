package EcoGrid.dto;

import java.math.BigDecimal;

public record DashboardSummaryDto(
        BigDecimal demandaActualMw,
        BigDecimal demandaPrevistaMw,
        BigDecimal costeDesvioEstimadoEur,
        long alertasActivas
) {
}