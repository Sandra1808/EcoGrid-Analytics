package EcoGrid.service;

import EcoGrid.dao.AlertasOperativaRepository;
import EcoGrid.dao.DemandageneracionreeRepository;
import EcoGrid.dao.ImpactodesviacioneRepository;
import EcoGrid.dao.PrediccionesdemandaRepository;
import EcoGrid.dto.DashboardSummaryDto;
import EcoGrid.dto.DemandaHistoricaDto;
import EcoGrid.dto.DemandaSerieDto;
import EcoGrid.dto.PrediccionDto;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZoneOffset;
import java.util.Map;
import java.util.TreeMap;

@Service
public class DashboardService {

    private static final Long ID_ESPANA = 1L;
    private static final ZoneId ZONA_ESPANA = ZoneId.of("Europe/Madrid");

    private final DemandaHistoricaService demandaHistoricaService;
    private final PrediccionesService prediccionesService;
    private final DemandageneracionreeRepository demandaRepository;
    private final PrediccionesdemandaRepository prediccionesRepository;
    private final ImpactodesviacioneRepository impactosRepository;
    private final AlertasOperativaRepository alertasRepository;

    public DashboardService(
            DemandaHistoricaService demandaHistoricaService,
            PrediccionesService prediccionesService,
            DemandageneracionreeRepository demandaRepository,
            PrediccionesdemandaRepository prediccionesRepository,
            ImpactodesviacioneRepository impactosRepository,
            AlertasOperativaRepository alertasRepository) {
        this.demandaHistoricaService = demandaHistoricaService;
        this.prediccionesService = prediccionesService;
        this.demandaRepository = demandaRepository;
        this.prediccionesRepository = prediccionesRepository;
        this.impactosRepository = impactosRepository;
        this.alertasRepository = alertasRepository;
    }

    @Transactional(readOnly = true)
    public DashboardSummaryDto resumen() {
        var demanda = demandaRepository
                .findFirstByIdccaa_IdOrderByIdtiempo_FechoraDesc(ID_ESPANA)
                .orElse(null);

        var prediccion = prediccionesRepository
                .findFirstByIdccaa_IdOrderByIdtiempo_FechoraDesc(ID_ESPANA)
                .orElse(null);

        Instant ahora = Instant.now();
        LocalDate hoyMadrid = ahora.atZone(ZONA_ESPANA).toLocalDate();

        LocalDateTime desdeUtc = hoyMadrid.atStartOfDay(ZONA_ESPANA)
                .toInstant()
                .atOffset(ZoneOffset.UTC)
                .toLocalDateTime();

        LocalDateTime hastaUtc = LocalDateTime.ofInstant(ahora, ZoneOffset.UTC);

        BigDecimal costeHoy = impactosRepository.sumarCosteDesvio(
                ID_ESPANA, desdeUtc, hastaUtc);

        return new DashboardSummaryDto(
                demanda == null ? null : demanda.getDemandarealmw(),
                prediccion == null ? null : prediccion.getDemandapredichamw(),
                costeHoy,
                alertasRepository.contarActivas()
        );
    }

    @Transactional(readOnly = true)
    public java.util.List<DemandaSerieDto> serie(
            Long ccaaId, Instant desde, Instant hasta) {

        if (desde == null || hasta == null) {
            throw new org.springframework.web.server.ResponseStatusException(
                    org.springframework.http.HttpStatus.BAD_REQUEST,
                    "Debes indicar desde/hasta o from/to");
        }

        Map<Instant, PuntoSerie> puntos = new TreeMap<>();

        for (DemandaHistoricaDto dato :
                demandaHistoricaService.buscar(ccaaId, desde, hasta)) {
            PuntoSerie punto = puntos.computeIfAbsent(
                    dato.fechaHora(), ignored -> new PuntoSerie());
            punto.demandaRealMw = dato.demandaRealMw();
            punto.demandaPrevistaReeMw = dato.demandaPrevistaReeMw();
            punto.demandaProgramadaMw = dato.demandaProgramadaMw();
            punto.demandaProgramadaTotalMw = dato.demandaProgramadaTotalMw();
        }

        if (ccaaId.equals(ID_ESPANA)) {
            for (PrediccionDto dato :
                    prediccionesService.listarNacional(desde, hasta)) {
                PuntoSerie punto = puntos.computeIfAbsent(
                        dato.fechaHora(), ignored -> new PuntoSerie());
                punto.demandaPredichaMw = dato.demandaPredichaMw();
                punto.demandaBaselineMw = dato.demandaBaselineMw();
            }
        }

        return puntos.entrySet().stream()
                .map(entry -> new DemandaSerieDto(
                        entry.getKey(),
                        entry.getValue().demandaRealMw,
                        entry.getValue().demandaPrevistaReeMw,
                        entry.getValue().demandaPredichaMw,
                        entry.getValue().demandaBaselineMw,
                        entry.getValue().demandaProgramadaMw,
                        entry.getValue().demandaProgramadaTotalMw))
                .toList();
    }

    private static class PuntoSerie {
        private BigDecimal demandaRealMw;
        private BigDecimal demandaPrevistaReeMw;
        private BigDecimal demandaPredichaMw;
        private BigDecimal demandaBaselineMw;
        private BigDecimal demandaProgramadaMw;
        private BigDecimal demandaProgramadaTotalMw;
    }
}