package EcoGrid.dao;

import EcoGrid.entity.AlertasOperativa;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface AlertasOperativaRepository
        extends JpaRepository<AlertasOperativa, Long> {

    @EntityGraph(attributePaths = "idtiempo")
    List<AlertasOperativa> findAllByOrderByIdtiempo_FechoraDesc();

    @Query("""
            select count(a)
            from AlertasOperativa a
            where lower(a.estado) in ('activa', 'abierta', 'pendiente')
            """)
    long contarActivas();
}