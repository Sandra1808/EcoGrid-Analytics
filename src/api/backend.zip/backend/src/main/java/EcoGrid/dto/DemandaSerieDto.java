package EcoGrid.dto;

import java.math.BigDecimal;
import java.time.Instant;

public record DemandaSerieDto(
        Instant fechaHora,
        BigDecimal demandaRealMw,
        BigDecimal demandaPrevistaReeMw,
        BigDecimal demandaPredichaMw,
        BigDecimal demandaBaselineMw,
        BigDecimal demandaProgramadaMw,
        BigDecimal demandaProgramadaTotalMw
) {
}